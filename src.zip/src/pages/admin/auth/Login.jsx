import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
// day 19
import { useDispatch } from "react-redux";
import { login } from "../../../features/auth/authSlice";

// day21
import { userLogin } from "../../../api/userService";

export default function LoginForm() {
  const emailRef = useRef(null);
  const passwordRef = useRef(null);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  // day 19
  const dispatch = useDispatch();

  const formSubmit = (e) => {
    e.preventDefault();
    const err = validateData();
    if (Object.keys(err).length > 0) {
      return false;
    } else {
      let email = emailRef.current.value;
      let password = passwordRef.current.value;

      // call API - login API
      const response = userLogin({ email, password });

      // response.data => {
      //     id: user.id,
      //     name: user.name,
      //     role: user.role,
      //     email: user.email
      // }

      if (response.status == 1) {
        dispatch(login(response.data));
        navigate("/admin/dashboard");
      } else {
        console.log(response.message);
      }
    }
  };

  const validateData = () => {
    const errs = {};
    if (!emailRef.current.value) errs.email = "Email is Required";
    if (!passwordRef.current.value) errs.password = "Password is required";
    setErrors(errs);
    return errs;
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
        <div className="flex flex-col items-center mb-6">
          <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center text-white font-bold text-xl mb-3 shadow-sm">
            B
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Welcome Back</h2>
          <p className="text-sm text-gray-500 mt-1">
            Please enter your details to sign in
          </p>
        </div>

        <form onSubmit={formSubmit} className="space-y-4" autoComplete="off">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              ref={emailRef}
              placeholder="Enter Email"
              autoComplete="off"
              className="w-full py-2 px-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent transition-all text-gray-800 placeholder-gray-400"
            />
            {errors.email && (
              <p className="text-sm text-red-500 mt-1">{errors.email}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="password"
              ref={passwordRef}
              placeholder="Enter password"
              autoComplete="off"
              className="w-full py-2 px-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent transition-all text-gray-800 placeholder-gray-400"
            />
            {errors.password && (
              <p className="text-sm text-red-500 mt-1">{errors.password}</p>
            )}
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
            >
              Login
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
