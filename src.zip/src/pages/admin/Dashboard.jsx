function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-text mb-1">Dashboard</h1>
      <p className="text-text-muted text-sm">Admin panel is ready.</p>
    </div>
  );
}

export default Dashboard;
