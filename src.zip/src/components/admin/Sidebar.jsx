import { useState, useEffect } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  MessagesSquare,
  Store,
  GraduationCap,
  Map as MapIcon,
  Layers,
  BookOpen,
  ChevronDown,
  ArrowLeft,
} from "lucide-react";

const mainItems = [
  { to: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/admin/users", label: "Users", icon: Users },
  { to: "/admin/community", label: "Community Posts", icon: MessagesSquare },
  { to: "/admin/marketplace", label: "Market Items", icon: Store },
];

const learningItems = [
  { to: "/admin/learning/journeys", label: "Journeys", icon: MapIcon },
  { to: "/admin/learning/chapters", label: "Chapters", icon: Layers },
  { to: "/admin/learning/lessons", label: "Lessons", icon: BookOpen },
];

const linkClass = ({ isActive }) =>
  `shrink-0 flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
    isActive
      ? "bg-primary/15 text-primary"
      : "text-text-muted hover:text-text hover:bg-surface"
  }`;

function Sidebar() {
  const { pathname } = useLocation();
  const isLearningActive = pathname.startsWith("/admin/learning");

  // Learning group ကို ဖွင့်/ပိတ်မယ့် state
  const [learningOpen, setLearningOpen] = useState(isLearningActive);

  // URL ကနေ တိုက်ရိုက် learning page ရောက်လာရင် group ကို အလိုလို ဖွင့်ပေး
  useEffect(() => {
    if (isLearningActive) setLearningOpen(true);
  }, [isLearningActive]);

  return (
    <aside className="md:w-60 shrink-0 bg-bg-elevated border-b md:border-b-0 md:border-r border-border p-3 md:p-4 md:sticky md:top-0 md:h-screen md:overflow-y-auto">
      <p className="hidden md:block text-xs font-bold text-text-subtle uppercase tracking-wider mb-3 px-2">
        Admin Panel
      </p>

      <nav className="flex md:flex-col gap-1 overflow-x-auto">
        {mainItems.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} className={linkClass}>
            <Icon size={16} /> {label}
          </NavLink>
        ))}

        {/* Learning group */}
        <div className="flex md:flex-col gap-1">
          {/* group header — desktop မှာပဲ ပြ (mobile မှာ tab တွေ တန်းစီပြမယ်) */}
          <button
            type="button"
            onClick={() => setLearningOpen((prev) => !prev)}
            className={`hidden md:flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              isLearningActive
                ? "text-primary"
                : "text-text-muted hover:text-text hover:bg-surface"
            }`}
          >
            <span className="flex items-center gap-2">
              <GraduationCap size={16} /> Learning
            </span>
            <ChevronDown
              size={14}
              className={`transition-transform ${learningOpen ? "rotate-180" : ""}`}
            />
          </button>

          {/* children — mobile မှာ အမြဲပြ၊ md မှာ learningOpen နဲ့ ထိန်း */}
          <div
            className={`flex md:flex-col gap-1 md:ml-3 md:pl-2 md:border-l md:border-border ${
              learningOpen ? "md:flex" : "md:hidden"
            }`}
          >
            {learningItems.map(({ to, label, icon: Icon }) => (
              <NavLink key={to} to={to} className={linkClass}>
                <Icon size={15} /> {label}
              </NavLink>
            ))}
          </div>
        </div>
      </nav>

      <Link
        to="/"
        className="hidden md:flex items-center gap-2 mt-6 px-3 py-2 text-xs text-text-subtle hover:text-text"
      >
        <ArrowLeft size={14} /> Back to site
      </Link>
    </aside>
  );
}

export default Sidebar;
