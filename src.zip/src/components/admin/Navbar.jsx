import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";
import { logout } from "../../features/auth/authSlice";

function Navbar() {
  const user = useSelector((state) => state.auth.user);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate("/admin");
  };

  return (
    <header className="h-14 shrink-0 bg-bg-elevated border-b border-border px-4 md:px-8 flex items-center justify-between">
      <span className="text-sm font-semibold text-text">
        MakerHub MM · Admin
      </span>

      <div className="flex items-center gap-3">
        <span className="hidden sm:inline text-xs text-text-muted">
          {user?.name}
        </span>
        <button
          onClick={handleLogout}
          className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-surface border border-border text-text-muted hover:text-red-400 hover:border-red-500/30 transition-colors"
        >
          <LogOut size={13} /> Logout
        </button>
      </div>
    </header>
  );
}

export default Navbar;
